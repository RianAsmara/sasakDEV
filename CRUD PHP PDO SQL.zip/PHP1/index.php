<?php
    require_once('lib/koneksi.php');
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PHP 1</title>
        <link href="./css/bootstrap.min.css" rel="stylesheet">
        <link href="./css/style.css" rel="stylesheet">
    </head>

    <body>
        <div class="container">
            <h4>Daftar Mahasiswa</h4>
            <hr>
            <a href="lib/tambah.php" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span> Tambah Data Mahasiswa</a>
            <hr>
            <table class="table table-bordered">
                <tr>
                    <th>ID Mahasiswa</th>
                    <th>Nama Mahasiswa</th>
                    <th>Alamat Mahasiswa</th>
                    <th>Kelas Mahasiswa</th>
                    <th>Aksi</th>
                </tr>
                <?php
                
                    $masukan = $con->prepare("SELECT * FROM mahasiswa ORDER BY idmahasiswa ASC");
                    $masukan->execute();
                    $results = $masukan->fetchAll();
                    foreach($results as $row){
                
                ?>
                    <tr>
                        <td>
                            <?=$row['idmahasiswa'];?>
                        </td>
                        <td>
                            <?=$row['nama_mahasiswa'];?>
                        </td>
                        <td>
                            <?=$row['alamat_mahasiswa'];?>
                        </td>
                        <td>
                            <?=$row['kelas_mahasiswa'];?>
                        </td>
                        <td>
                            <a class="btn btn-info glyphicon glyphicon-pencil" href="lib/edit.php?id=<?=$row['idmahasiswa']?>"></a>
                            <a class="btn btn-danger glyphicon glyphicon-remove" href="lib/hapus.php?id=<?=$row['idmahasiswa']?>"></a>
                        </td>
                    </tr>
                    <?php
                        }
                    ?>
            </table>

        </div>
        <script src="./js/jquery-3.1.1.min.js"></script>
        <script src="./js/bootstrap.min.js"></script>
    </body>

    </html>