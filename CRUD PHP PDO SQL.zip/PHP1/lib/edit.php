<?php
    require_once('koneksi.php');

    if(isset($_POST['Submit'])){
        $id = $_POST['idmahasiswa']; 
        $nama = $_POST['nama_mahasiswa']; 
        $almt = $_POST['alamat_mahasiswa']; 
        $kls = $_POST['kelas_mahasiswa']; 
        if(!empty($nama)){ 
            try{ 
                $masukan = $con->prepare("UPDATE mahasiswa set nama_mahasiswa = :nama,alamat_mahasiswa=:almt,kelas_mahasiswa=:kls WHERE idmahasiswa = :id"); 
                
                $masukan->execute(array(':nama'=>$nama,':almt'=>$almt,':kls'=>$kls,':id'=>$id)); 
                
                header('Location:../index.php'); 
                
            }catch(PDOException $ex){ 
                
                echo $ex->getMessage(); 
                
            } 
        }else{ 
            echo "Masukkan Nama Mahasiswa";
        }
    }
//Edit Syntax

$idmahasiswa = 0;
$nama = '';
$almt = '';
$kls = '';
if(isset($_GET['id'])){
$id = $_GET['id']; //Menghapus Data Berdasarkan ID
    $masukan = $con->prepare('SELECT * FROM mahasiswa WHERE idmahasiswa = :id');
    $masukan->execute(array(':id'=>$id));
    $row = $masukan->fetch();
    $idmahasiswa = $row['idmahasiswa'];
    $nmmahasiswa = $row['nama_mahasiswa'];
    $almtmahasiswa = $row['alamat_mahasiswa'];
    $klsmahasiswa = $row['kelas_mahasiswa'];
}
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PHP 1</title>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
        <div class="container">
            <div class="col-md-12">
                <h4>Insert Data Mahasiswa</h4>
                <hr>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="lnmmhs">ID Mahasiswa</label>
                        <input type="text" class="form-control" id="lidmhs" name="idmahasiswa" value="<?=$idmahasiswa;?>" readonly>
                        <label for="lnmmhs">Nama Mahasiswa</label>
                        <input type="text" class="form-control" id="lnmmhs" name="nama_mahasiswa" value="<?=$nmmahasiswa;?>">
                        <label for="lalmtmhs">Alamat Mahasiswa</label>
                        <input type="text" class="form-control" id="lalmtmhs" name="alamat_mahasiswa" value="<?=$almtmahasiswa;?>">
                        <label for="lklsmhs">Kelas Mahasiswa</label>
                        <input type="text" class="form-control" id="lklsmhs" name="kelas_mahasiswa" value="<?=$klsmahasiswa;?>">
                    </div>
                    <button type="submit" name="Submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
        <script src="../js/jquery-3.1.1.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </body>

    </html>