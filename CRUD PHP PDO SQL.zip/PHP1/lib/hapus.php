<?php
require_once('koneksi.php');
if(isset($_GET['id'])){ //Menghapus Data Berdasarkan ID
$id = $_GET['id'];
    try{
        
    $hapus = $con->prepare("DELETE FROM mahasiswa WHERE idmahasiswa=?");
    
    $hapus->execute(array($id));
    
    header('Location:../index.php'); 
    
    }catch(PDOException $ex){
    
    echo $ex->getMessage();
    
    }
}
?>