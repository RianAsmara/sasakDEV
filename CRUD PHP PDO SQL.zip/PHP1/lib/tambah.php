<?php
    require_once('koneksi.php');

    if(isset($_POST['btn_Simpan'])){
        $nama = $_POST['nama_mahasiswa']; 
        $almt = $_POST['alamat_mahasiswa']; 
        $kls = $_POST['kelas_mahasiswa']; 
        if(!empty($nama)){ 
            try{ 
                $masukan = $con->prepare("INSERT INTO mahasiswa(nama_mahasiswa,alamat_mahasiswa,kelas_mahasiswa)
                VALUES(:nama,:almt,:kls)"); 
                
                $masukan->execute(array(':nama'=>$nama,':almt'=>$almt,':kls'=>$kls)); 
                
                header('Location:../index.php'); 
                
            }catch(PDOException $ex){ 
                
                echo $ex->getMessage(); 
                
            } 
        }else{ 
            echo "Masukkan Nama Mahasiswa";
        }
    }
?>
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>PHP 1</title>
        <link href="../css/bootstrap.min.css" rel="stylesheet">
    </head>

    <body>
        <div class="container">
            <div class="col-md-12">
                <h4>Insert Data Mahasiswa</h4>
                <hr>
                <form action="" method="post">
                    <div class="form-group">
                        <label for="lnmmhs">Nama Mahasiswa</label>
                        <input type="text" class="form-control" id="lnmmhs" name="nama_mahasiswa">
                        <label for="lalmtmhs">Alamat Mahasiswa</label>
                        <input type="text" class="form-control" id="lalmtmhs" name="alamat_mahasiswa">
                        <label for="lklsmhs">Kelas Mahasiswa</label>
                        <input type="text" class="form-control" id="lklsmhs" name="kelas_mahasiswa">
                    </div>
                    <button type="submit" name="btn_Simpan" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
        <script src="../js/jquery-3.1.1.min.js"></script>
        <script src="../js/bootstrap.min.js"></script>
    </body>

    </html>